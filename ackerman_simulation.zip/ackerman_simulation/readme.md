
* 操作指令

  roslaunch bringup racecar_gazebo.launch

  

  roslaunch bringup racecar.launch
  rosrun racecar_description servo_commands.py
  rosrun racecar_description keyboard_teleop.py



* 安装指令

  sudo apt install ros-melodic-teb-local-planner

  


